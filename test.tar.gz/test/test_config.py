import os

# Generated config by MitoFlex's config generation

command = 'all'
workname = 'test'
threads = os.cpu_count()
keep_temp = False
basedir = '.'
level = 'debug'
use_list = True
disable_local = False
kmer_list = '31,39,59,79,99,119,141'
kmer_min = 31
kmer_max = 141
kmer_step = 22
prune_level = 3
prune_depth = 3
additional_kmers = ''
cleanq1 = None
cleanq2 = None
deduplication = False
Ns_valve = 10
quality_valve = 55
percentage_valve = 0.2
keep_region = '0,0'
trimming = 5
fastq1 = './test.1.fq'
fastq2 = './test.2.fq'
fastq_alter_format = False
fastq_read_length = 150
disable_taxa = False
min_abundance = 10
required_taxa = 'Arthropoda'
taxa_tolerance = 0
genetic_code = 5
clade = 'Arthropoda'
max_contig_length = 20000
wider_taxa = False
disable_annotation = False
species_name = 'Test sp.'
use_hmmer = False
hmmer_score = 5.0
hmmer_e = 0.005
disable_visualization = False
disable_filter = False
